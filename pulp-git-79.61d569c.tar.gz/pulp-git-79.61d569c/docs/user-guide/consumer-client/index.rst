Consumer Client
===============

.. what is this, where does it run, etc

Contents:

.. toctree::
   :maxdepth: 2

   introduction
   register
   update
   bind
   history
   status
   nodes
   repositories
