USER_CONFIG_DIR = '~/.pulp/'
