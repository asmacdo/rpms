Permission APIs
===============

.. toctree::
   :maxdepth: 3

   actions
   retrieval
