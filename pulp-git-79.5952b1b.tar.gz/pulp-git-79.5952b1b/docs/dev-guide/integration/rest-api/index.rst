REST API
================

.. toctree::
   :maxdepth: 2

   authentication
   consumer/index
   consumer/group/index
   repo/index
   repo/groups/index
   content/index
   dispatch/index
   event/index
   user/index
   role/index
   permission/index
   status

