Troubleshooting
===============

.. _trailing_slashes:

Trailing Slashes
----------------

The REST API for Pulp is inconsistent with the use of trailing slashes in REST calls. If you are having trouble, try adding or removing the trailing slash.
