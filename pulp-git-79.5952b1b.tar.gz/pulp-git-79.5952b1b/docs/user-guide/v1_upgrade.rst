:orphan:

Pulp v1 Upgrades
================

Pulp no longer supports directly upgrading from Pulp 1.1 to the latest release. If you wish to
upgrade from Pulp 1.1 to the latest release of Pulp, you must first
`upgrade from 1.1 to 2.1 <https://pulp-user-guide.readthedocs.org/en/pulp-2.1/v1_upgrade.html>`_.

Once you have successfully upgraded to 2.1, you may use the ordinary upgrade system to move from 2.1
to the latest release of Pulp.
