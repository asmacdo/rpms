Release Notes
=============

Contents:

.. toctree::
   :maxdepth: 2

   master
   2.6.x
   2.5.x
   2.4.x
   2.3.x
   2.2.x
   2.1.x
