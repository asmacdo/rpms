
openssl crl -text -in certs/Pulp_CRL.pem -noout
