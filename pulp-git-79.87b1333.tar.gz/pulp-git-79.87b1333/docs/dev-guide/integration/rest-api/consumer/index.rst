Consumer APIs
=============

.. toctree::
   :maxdepth: 3

   cud
   bind
   retrieval
   content
   scheduled_content
   history
   profile
   applicability
