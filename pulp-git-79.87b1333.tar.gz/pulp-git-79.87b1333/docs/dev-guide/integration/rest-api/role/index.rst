Role APIs
=============

.. toctree::
   :maxdepth: 3

   cud
   retrieval
