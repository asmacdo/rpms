Implementing Support for New Types
==================================

.. toctree::
   :maxdepth: 3

   plugin/index
   client/index
   agent/index
