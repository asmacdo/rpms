Conventions
===========

.. toctree::
   :maxdepth: 3

   criteria
   exceptions
   sync-v-async
   scheduled
