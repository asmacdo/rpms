from setuptools import setup, find_packages

setup(
    name='pulp_node_common',
    version='2.6.0',
    license='GPLv2+',
    packages=find_packages(),
    author='Pulp Team',
    author_email='pulp-list@redhat.com',
)
