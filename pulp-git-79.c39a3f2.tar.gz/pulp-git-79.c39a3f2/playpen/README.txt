This directory is for scripts and other tools to help manage, test, and debug
pulp. Feel free to drop anything you like in here, but please take a little
time to document it.

- The Pulp Team
