Compatibility
=============

Python Version
--------------

All server components must support Python 2.6. This includes importers,
distributors, managers, middleware, and related code.

All client-side components must support python 2.4. This includes extensions and
handlers.